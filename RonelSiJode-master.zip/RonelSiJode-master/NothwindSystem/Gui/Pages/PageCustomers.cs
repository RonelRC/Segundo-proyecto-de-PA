﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DGV.Framework;
using NothwindSystem.Data;
using NothwindSystem.Data.Models;
using ServiceStack.OrmLite;
using NothwindSystem.Gui.Forms.Dialogs;

namespace NothwindSystem.Gui.Pages
{
    public partial class PageCustomers : UserControl
    {
        public PageCustomers()
        {
            if (Program.IsInDesignMode(this)) return;
            InitializeComponent();
            LoadData();
        }


        void LoadData()
        {
            var db = Data.db.Get();
            var data = db.Select<Customer>().Where(x => x.Deleted == false);

           grid.Bind(data);

        }

        private void PageCustomers_Load(object sender, EventArgs e)
        { 
            grid.OnDelete<Customer>((r, s) => db.Get().Delete(r) > 0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            grid.DeleteRow<Customer>();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new FrmCustomer().ShowDialog();
            LoadData();
        }

        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex != 0) return;

            new FrmCustomer(grid.GetCurrentRecord<Customer>()).ShowDialog();
            LoadData();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch.Text.Trim().Length == 0) LoadData();
        }

        private void txtSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) txtSearch.Text = string.Empty;

            if (e.KeyCode != Keys.Enter) return;

            LoadData();
            grid.SearchRows(txtSearch.Text);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            grid.DeleteRow<Category>();

        }
    }
}
