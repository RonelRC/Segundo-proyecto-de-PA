﻿using NothwindSystem.Data;
using NothwindSystem.Data.Models;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NothwindSystem.Gui.Forms.Dialogs
{
    public partial class FrmOrder : Form
    {
        Order _Order;
        public FrmOrder(Order Order = null)
        {
            this._Order = Order ?? new Order();
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmOrder_Load(object sender, EventArgs e)
        {
            var db = Data.db.Get();
            lstCutomer.DataSource = db.Select<Customer>(x => x.Deleted == false);
            lstEmployess.DataSource = db.Select<Employee>(x => x.Deleted == false);
            lstSHipper.DataSource = db.Select<Shipper>(x => x.Deleted == false);
             bindingProvider1.Bind(_Order);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validationProvider1.Validate().Length > 0) return;
            db.Get().Save(_Order);
            bunifuSnackbar1.Show(this, "Successfull", Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success);
        }

    }
}
