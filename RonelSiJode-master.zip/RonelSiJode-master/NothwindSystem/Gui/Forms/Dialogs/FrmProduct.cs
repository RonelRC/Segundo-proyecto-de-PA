﻿using NothwindSystem.Data;
using NothwindSystem.Data.Models;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NothwindSystem.Gui.Forms.Dialogs
{
    public partial class FrmProduct : Form
    {
        Product _Product;
        public FrmProduct(Product Product = null)
        {
            this._Product = Product ?? new Product();

            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmProduct_Load(object sender, EventArgs e)
        {
            var db = Data.db.Get();
            cSupplier.DataSource = db.Select<Supplier>(x => x.Deleted == false);
            cCategory.DataSource = db.Select<Category>(x => x.Deleted == false); 
             bindingProvider1.Bind(_Product);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validationProvider1.Validate().Length > 0) return;
            db.Get().Save(_Product);
            bunifuSnackbar1.Show(this, "Successfull", Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success);
        }

       
    }
}
