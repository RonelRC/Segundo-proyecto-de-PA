﻿using NothwindSystem.Data;
using NothwindSystem.Data.Models;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NothwindSystem.Gui.Forms.Dialogs
{
    public partial class FrmOrderItem : Form
    {
        Order _order;
        OrderItem _item;
        public FrmOrderItem(Order order, OrderItem item = null)
        {
            this._item = item??new OrderItem() { OrderID = order.Id};
            this._order = order;
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmShipper_Load(object sender, EventArgs e)
        {
            cProducts.DataSource = db.Get().Select<Product>(x => x.Deleted == false);
            bindingProvider1.Bind(_item);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validationProvider1.Validate().Length > 0) return;
            db.Get().Save(_item);
            bunifuSnackbar1.Show(this, "Successfull", Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success);
        }

        private void cProducts_SelectionChangeCommitted(object sender, EventArgs e)
        {
           _item.ProductID= ((Product)cProducts.SelectedItem).Id;
            txtUnitPrice.Text = ((Product)cProducts.SelectedItem).UnitPrice.ToString();
        }

       
    }
}
