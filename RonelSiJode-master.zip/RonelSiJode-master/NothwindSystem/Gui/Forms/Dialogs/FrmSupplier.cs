﻿using NothwindSystem.Data;
using NothwindSystem.Data.Models;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NothwindSystem.Gui.Forms.Dialogs
{
    public partial class FrmSupplier : Form
    {
        Supplier _Supplier;
        public FrmSupplier(Supplier Supplier = null)
        {
            this._Supplier = Supplier ?? new Supplier();
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmSupplier_Load(object sender, EventArgs e)
        {
            bindingProvider1.Bind(_Supplier);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validationProvider1.Validate().Length > 0) return;
            db.Get().Save(_Supplier);
            bunifuSnackbar1.Show(this, "Successfull", Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success);
        }

       
    }
}
