﻿using NothwindSystem.Data;
using NothwindSystem.Data.Models;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NothwindSystem.Gui.Forms.Dialogs
{
    public partial class FrmShipper : Form
    {
        Shipper _Shipper;
        public FrmShipper(Shipper Shipper = null)
        {
            this._Shipper = Shipper ?? new Shipper();
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmShipper_Load(object sender, EventArgs e)
        {
            bindingProvider1.Bind(_Shipper);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validationProvider1.Validate().Length > 0) return;
            db.Get().Save(_Shipper);
            bunifuSnackbar1.Show(this, "Successfull", Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success);
        }

    }
}
