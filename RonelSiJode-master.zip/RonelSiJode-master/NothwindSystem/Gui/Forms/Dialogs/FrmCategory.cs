﻿using NothwindSystem.Data;
using NothwindSystem.Data.Models;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NothwindSystem.Gui.Forms.Dialogs
{
    public partial class FrmCategory : Form
    {
        Category _Category;
        public FrmCategory(Category Category = null)
        {
            this._Category = Category ?? new Category();
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmCategory_Load(object sender, EventArgs e)
        {
            bindingProvider1.Bind(_Category);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validationProvider1.Validate().Length > 0) return;
            db.Get().Save(_Category);
            bunifuSnackbar1.Show(this, "Successfull", Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success);
        }

       
    }
}
