﻿namespace NothwindSystem.Gui.Forms.Dialogs
{
    partial class FrmOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Kimtoo.ValidationProvider.ValidationObject validationObject3 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject3 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject4 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject4 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject5 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject5 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject6 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject6 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject7 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject7 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject8 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject8 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject9 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject9 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject10 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject10 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject11 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject11 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject12 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject12 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject13 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject13 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject14 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject14 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject15 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject15 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject16 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject16 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject17 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject17 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject18 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject18 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject19 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject19 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject20 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject20 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject21 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject21 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject22 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject22 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject23 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject23 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject24 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject24 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject25 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject25 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject26 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject26 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject27 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject27 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject28 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject28 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject29 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject29 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject30 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject30 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            Kimtoo.ValidationProvider.ValidationObject validationObject1 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject1 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmOrder));
            Kimtoo.ValidationProvider.ValidationObject validationObject2 = new Kimtoo.ValidationProvider.ValidationObject();
            Kimtoo.BindingProvider.BindingProvider.BindingObject bindingObject2 = new Kimtoo.BindingProvider.BindingProvider.BindingObject();
            this.docker = new Bunifu.UI.WinForms.BunifuFormDock();
            this.bunifuSnackbar1 = new Bunifu.UI.WinForms.BunifuSnackbar(this.components);
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bunifuDatePicker3 = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.bunifuDatePicker2 = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.bunifuDatePicker1 = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.lstSHipper = new Bunifu.UI.WinForms.BunifuDropdown();
            this.label12 = new System.Windows.Forms.Label();
            this.lstEmployess = new Bunifu.UI.WinForms.BunifuDropdown();
            this.label11 = new System.Windows.Forms.Label();
            this.lstCutomer = new Bunifu.UI.WinForms.BunifuDropdown();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.validationProvider1 = new Kimtoo.ValidationProvider.ValidationProvider();
            this.label14 = new System.Windows.Forms.Label();
            this.bunifuCheckBox2 = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.bindingProvider1 = new Kimtoo.BindingProvider.BindingProvider();
            this.SuspendLayout();
            // 
            // docker
            // 
            this.docker.AllowFormDragging = true;
            this.docker.AllowFormDropShadow = true;
            this.docker.AllowFormResizing = false;
            this.docker.AllowHidingBottomRegion = true;
            this.docker.AllowOpacityChangesWhileDragging = false;
            this.docker.BorderOptions.BottomBorder.BorderColor = System.Drawing.Color.Silver;
            this.docker.BorderOptions.BottomBorder.BorderThickness = 1;
            this.docker.BorderOptions.BottomBorder.ShowBorder = true;
            this.docker.BorderOptions.LeftBorder.BorderColor = System.Drawing.Color.Silver;
            this.docker.BorderOptions.LeftBorder.BorderThickness = 1;
            this.docker.BorderOptions.LeftBorder.ShowBorder = true;
            this.docker.BorderOptions.RightBorder.BorderColor = System.Drawing.Color.Silver;
            this.docker.BorderOptions.RightBorder.BorderThickness = 1;
            this.docker.BorderOptions.RightBorder.ShowBorder = true;
            this.docker.BorderOptions.TopBorder.BorderColor = System.Drawing.Color.Silver;
            this.docker.BorderOptions.TopBorder.BorderThickness = 1;
            this.docker.BorderOptions.TopBorder.ShowBorder = true;
            this.docker.ContainerControl = this;
            this.docker.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.docker.DockingIndicatorsOpacity = 0.5D;
            this.docker.DockingOptions.DockAll = true;
            this.docker.DockingOptions.DockBottomLeft = true;
            this.docker.DockingOptions.DockBottomRight = true;
            this.docker.DockingOptions.DockFullScreen = true;
            this.docker.DockingOptions.DockLeft = true;
            this.docker.DockingOptions.DockRight = true;
            this.docker.DockingOptions.DockTopLeft = true;
            this.docker.DockingOptions.DockTopRight = true;
            this.docker.FormDraggingOpacity = 0.9D;
            this.docker.ParentForm = this;
            this.docker.ShowCursorChanges = true;
            this.docker.ShowDockingIndicators = false;
            this.docker.TitleBarOptions.AllowFormDragging = true;
            this.docker.TitleBarOptions.BunifuFormDock = this.docker;
            this.docker.TitleBarOptions.DoubleClickToExpandWindow = false;
            this.docker.TitleBarOptions.TitleBarControl = null;
            this.docker.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            // 
            // bunifuSnackbar1
            // 
            this.bunifuSnackbar1.AllowDragging = false;
            this.bunifuSnackbar1.AllowMultipleViews = true;
            this.bunifuSnackbar1.ClickToClose = true;
            this.bunifuSnackbar1.DoubleClickToClose = true;
            this.bunifuSnackbar1.DurationAfterIdle = 3000;
            this.bunifuSnackbar1.ErrorOptions.ActionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSnackbar1.ErrorOptions.ActionBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSnackbar1.ErrorOptions.ActionBorderRadius = 1;
            this.bunifuSnackbar1.ErrorOptions.ActionFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.bunifuSnackbar1.ErrorOptions.ActionForeColor = System.Drawing.Color.Black;
            this.bunifuSnackbar1.ErrorOptions.BackColor = System.Drawing.Color.White;
            this.bunifuSnackbar1.ErrorOptions.BorderColor = System.Drawing.Color.White;
            this.bunifuSnackbar1.ErrorOptions.CloseIconColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(199)))));
            this.bunifuSnackbar1.ErrorOptions.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.bunifuSnackbar1.ErrorOptions.ForeColor = System.Drawing.Color.Black;
            this.bunifuSnackbar1.ErrorOptions.Icon = ((System.Drawing.Image)(resources.GetObject("resource.Icon")));
            this.bunifuSnackbar1.ErrorOptions.IconLeftMargin = 12;
            this.bunifuSnackbar1.FadeCloseIcon = false;
            this.bunifuSnackbar1.Host = Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner;
            this.bunifuSnackbar1.InformationOptions.ActionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSnackbar1.InformationOptions.ActionBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSnackbar1.InformationOptions.ActionBorderRadius = 1;
            this.bunifuSnackbar1.InformationOptions.ActionFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.bunifuSnackbar1.InformationOptions.ActionForeColor = System.Drawing.Color.Black;
            this.bunifuSnackbar1.InformationOptions.BackColor = System.Drawing.Color.White;
            this.bunifuSnackbar1.InformationOptions.BorderColor = System.Drawing.Color.White;
            this.bunifuSnackbar1.InformationOptions.CloseIconColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(213)))), ((int)(((byte)(255)))));
            this.bunifuSnackbar1.InformationOptions.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.bunifuSnackbar1.InformationOptions.ForeColor = System.Drawing.Color.Black;
            this.bunifuSnackbar1.InformationOptions.Icon = ((System.Drawing.Image)(resources.GetObject("resource.Icon1")));
            this.bunifuSnackbar1.InformationOptions.IconLeftMargin = 12;
            this.bunifuSnackbar1.Margin = 10;
            this.bunifuSnackbar1.MaximumSize = new System.Drawing.Size(0, 0);
            this.bunifuSnackbar1.MaximumViews = 7;
            this.bunifuSnackbar1.MessageRightMargin = 15;
            this.bunifuSnackbar1.MinimumSize = new System.Drawing.Size(0, 0);
            this.bunifuSnackbar1.ShowBorders = false;
            this.bunifuSnackbar1.ShowCloseIcon = false;
            this.bunifuSnackbar1.ShowIcon = true;
            this.bunifuSnackbar1.ShowShadows = true;
            this.bunifuSnackbar1.SuccessOptions.ActionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSnackbar1.SuccessOptions.ActionBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSnackbar1.SuccessOptions.ActionBorderRadius = 1;
            this.bunifuSnackbar1.SuccessOptions.ActionFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.bunifuSnackbar1.SuccessOptions.ActionForeColor = System.Drawing.Color.Black;
            this.bunifuSnackbar1.SuccessOptions.BackColor = System.Drawing.Color.White;
            this.bunifuSnackbar1.SuccessOptions.BorderColor = System.Drawing.Color.White;
            this.bunifuSnackbar1.SuccessOptions.CloseIconColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(255)))), ((int)(((byte)(237)))));
            this.bunifuSnackbar1.SuccessOptions.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.bunifuSnackbar1.SuccessOptions.ForeColor = System.Drawing.Color.Black;
            this.bunifuSnackbar1.SuccessOptions.Icon = ((System.Drawing.Image)(resources.GetObject("resource.Icon2")));
            this.bunifuSnackbar1.SuccessOptions.IconLeftMargin = 12;
            this.bunifuSnackbar1.ViewsMargin = 7;
            this.bunifuSnackbar1.WarningOptions.ActionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSnackbar1.WarningOptions.ActionBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSnackbar1.WarningOptions.ActionBorderRadius = 1;
            this.bunifuSnackbar1.WarningOptions.ActionFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.bunifuSnackbar1.WarningOptions.ActionForeColor = System.Drawing.Color.Black;
            this.bunifuSnackbar1.WarningOptions.BackColor = System.Drawing.Color.White;
            this.bunifuSnackbar1.WarningOptions.BorderColor = System.Drawing.Color.White;
            this.bunifuSnackbar1.WarningOptions.CloseIconColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(229)))), ((int)(((byte)(143)))));
            this.bunifuSnackbar1.WarningOptions.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.bunifuSnackbar1.WarningOptions.ForeColor = System.Drawing.Color.Black;
            this.bunifuSnackbar1.WarningOptions.Icon = ((System.Drawing.Image)(resources.GetObject("resource.Icon3")));
            this.bunifuSnackbar1.WarningOptions.IconLeftMargin = 12;
            this.bunifuSnackbar1.ZoomCloseIcon = true;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.White;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.ForeColor = System.Drawing.Color.Black;
            validationObject3.CustomErrorMessage = "";
            validationObject3.Optional = false;
            validationObject3.Regex = "(.|\\s)*\\S(.|\\s)*";
            validationObject3.TargetMember = "Text";
            validationObject3.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.NotEmpty;
            this.validationProvider1.SetLink(this.textBox7, validationObject3);
            bindingObject3.BindingMember = "ShipCountry";
            bindingObject3.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.textBox7, bindingObject3);
            this.textBox7.Location = new System.Drawing.Point(35, 473);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(288, 27);
            this.textBox7.TabIndex = 43;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject4.CustomErrorMessage = "";
            validationObject4.Optional = false;
            validationObject4.Regex = null;
            validationObject4.TargetMember = "Text";
            validationObject4.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label10, validationObject4);
            bindingObject4.BindingMember = "";
            bindingObject4.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label10, bindingObject4);
            this.label10.Location = new System.Drawing.Point(30, 449);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 19);
            this.label10.TabIndex = 42;
            this.label10.Text = "Ship Country";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.ForeColor = System.Drawing.Color.Black;
            validationObject5.CustomErrorMessage = "";
            validationObject5.Optional = false;
            validationObject5.Regex = "(.|\\s)*\\S(.|\\s)*";
            validationObject5.TargetMember = "Text";
            validationObject5.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.NotEmpty;
            this.validationProvider1.SetLink(this.textBox4, validationObject5);
            bindingObject5.BindingMember = "ShipPostalCode";
            bindingObject5.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.textBox4, bindingObject5);
            this.textBox4.Location = new System.Drawing.Point(620, 384);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(288, 27);
            this.textBox4.TabIndex = 41;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject6.CustomErrorMessage = "";
            validationObject6.Optional = false;
            validationObject6.Regex = null;
            validationObject6.TargetMember = "Text";
            validationObject6.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label7, validationObject6);
            bindingObject6.BindingMember = "";
            bindingObject6.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label7, bindingObject6);
            this.label7.Location = new System.Drawing.Point(616, 360);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 19);
            this.label7.TabIndex = 40;
            this.label7.Text = "Ship Postal Code";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.White;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.ForeColor = System.Drawing.Color.Black;
            validationObject7.CustomErrorMessage = "";
            validationObject7.Optional = false;
            validationObject7.Regex = "(.|\\s)*\\S(.|\\s)*";
            validationObject7.TargetMember = "Text";
            validationObject7.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.NotEmpty;
            this.validationProvider1.SetLink(this.textBox5, validationObject7);
            bindingObject7.BindingMember = "ShipRegion";
            bindingObject7.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.textBox5, bindingObject7);
            this.textBox5.Location = new System.Drawing.Point(326, 384);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(288, 27);
            this.textBox5.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject8.CustomErrorMessage = "";
            validationObject8.Optional = false;
            validationObject8.Regex = null;
            validationObject8.TargetMember = "Text";
            validationObject8.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label8, validationObject8);
            bindingObject8.BindingMember = "";
            bindingObject8.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label8, bindingObject8);
            this.label8.Location = new System.Drawing.Point(322, 360);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 19);
            this.label8.TabIndex = 38;
            this.label8.Text = "Ship Region";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.ForeColor = System.Drawing.Color.Black;
            validationObject9.CustomErrorMessage = "";
            validationObject9.Optional = false;
            validationObject9.Regex = "(.|\\s)*\\S(.|\\s)*";
            validationObject9.TargetMember = "Text";
            validationObject9.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.NotEmpty;
            this.validationProvider1.SetLink(this.textBox6, validationObject9);
            bindingObject9.BindingMember = "ShipCity";
            bindingObject9.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.textBox6, bindingObject9);
            this.textBox6.Location = new System.Drawing.Point(32, 384);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(288, 27);
            this.textBox6.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject10.CustomErrorMessage = "";
            validationObject10.Optional = false;
            validationObject10.Regex = null;
            validationObject10.TargetMember = "Text";
            validationObject10.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label9, validationObject10);
            bindingObject10.BindingMember = "";
            bindingObject10.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label9, bindingObject10);
            this.label9.Location = new System.Drawing.Point(27, 360);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 19);
            this.label9.TabIndex = 36;
            this.label9.Text = "Ship City";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject11.CustomErrorMessage = "";
            validationObject11.Optional = false;
            validationObject11.Regex = null;
            validationObject11.TargetMember = "Text";
            validationObject11.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label6, validationObject11);
            bindingObject11.BindingMember = "";
            bindingObject11.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label6, bindingObject11);
            this.label6.Location = new System.Drawing.Point(616, 177);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 19);
            this.label6.TabIndex = 35;
            this.label6.Text = "Shipped Dated";
            // 
            // bunifuDatePicker3
            // 
            this.bunifuDatePicker3.BackColor = System.Drawing.Color.White;
            this.bunifuDatePicker3.BorderColor = System.Drawing.Color.Silver;
            this.bunifuDatePicker3.BorderRadius = 1;
            this.bunifuDatePicker3.Color = System.Drawing.Color.Silver;
            this.bunifuDatePicker3.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.bunifuDatePicker3.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.bunifuDatePicker3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuDatePicker3.DisplayWeekNumbers = false;
            this.bunifuDatePicker3.DPHeight = 0;
            this.bunifuDatePicker3.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.bunifuDatePicker3.FillDatePicker = false;
            this.bunifuDatePicker3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuDatePicker3.ForeColor = System.Drawing.Color.Black;
            this.bunifuDatePicker3.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuDatePicker3.Icon")));
            this.bunifuDatePicker3.IconColor = System.Drawing.Color.Gray;
            this.bunifuDatePicker3.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.bunifuDatePicker3.LeftTextMargin = 5;
            validationObject12.CustomErrorMessage = "";
            validationObject12.Optional = false;
            validationObject12.Regex = null;
            validationObject12.TargetMember = "Text";
            validationObject12.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.bunifuDatePicker3, validationObject12);
            bindingObject12.BindingMember = "ShippedDate";
            bindingObject12.BindingProperty = "Value";
            this.bindingProvider1.SetLink(this.bunifuDatePicker3, bindingObject12);
            this.bunifuDatePicker3.Location = new System.Drawing.Point(620, 202);
            this.bunifuDatePicker3.MinimumSize = new System.Drawing.Size(4, 32);
            this.bunifuDatePicker3.Name = "bunifuDatePicker3";
            this.bunifuDatePicker3.Size = new System.Drawing.Size(288, 32);
            this.bunifuDatePicker3.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject13.CustomErrorMessage = "";
            validationObject13.Optional = false;
            validationObject13.Regex = null;
            validationObject13.TargetMember = "Text";
            validationObject13.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label5, validationObject13);
            bindingObject13.BindingMember = "";
            bindingObject13.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label5, bindingObject13);
            this.label5.Location = new System.Drawing.Point(324, 177);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 19);
            this.label5.TabIndex = 33;
            this.label5.Text = "Required Date";
            // 
            // bunifuDatePicker2
            // 
            this.bunifuDatePicker2.BackColor = System.Drawing.Color.White;
            this.bunifuDatePicker2.BorderColor = System.Drawing.Color.Silver;
            this.bunifuDatePicker2.BorderRadius = 1;
            this.bunifuDatePicker2.Color = System.Drawing.Color.Silver;
            this.bunifuDatePicker2.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.bunifuDatePicker2.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.bunifuDatePicker2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuDatePicker2.DisplayWeekNumbers = false;
            this.bunifuDatePicker2.DPHeight = 0;
            this.bunifuDatePicker2.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.bunifuDatePicker2.FillDatePicker = false;
            this.bunifuDatePicker2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuDatePicker2.ForeColor = System.Drawing.Color.Black;
            this.bunifuDatePicker2.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuDatePicker2.Icon")));
            this.bunifuDatePicker2.IconColor = System.Drawing.Color.Gray;
            this.bunifuDatePicker2.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.bunifuDatePicker2.LeftTextMargin = 5;
            validationObject14.CustomErrorMessage = "";
            validationObject14.Optional = false;
            validationObject14.Regex = null;
            validationObject14.TargetMember = "Text";
            validationObject14.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.bunifuDatePicker2, validationObject14);
            bindingObject14.BindingMember = "RequiredDate";
            bindingObject14.BindingProperty = "Value";
            this.bindingProvider1.SetLink(this.bunifuDatePicker2, bindingObject14);
            this.bunifuDatePicker2.Location = new System.Drawing.Point(326, 202);
            this.bunifuDatePicker2.MinimumSize = new System.Drawing.Size(4, 32);
            this.bunifuDatePicker2.Name = "bunifuDatePicker2";
            this.bunifuDatePicker2.Size = new System.Drawing.Size(288, 32);
            this.bunifuDatePicker2.TabIndex = 32;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject15.CustomErrorMessage = "";
            validationObject15.Optional = false;
            validationObject15.Regex = null;
            validationObject15.TargetMember = "Text";
            validationObject15.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label4, validationObject15);
            bindingObject15.BindingMember = "";
            bindingObject15.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label4, bindingObject15);
            this.label4.Location = new System.Drawing.Point(31, 177);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 19);
            this.label4.TabIndex = 31;
            this.label4.Text = "Order Date";
            // 
            // bunifuDatePicker1
            // 
            this.bunifuDatePicker1.BackColor = System.Drawing.Color.White;
            this.bunifuDatePicker1.BorderColor = System.Drawing.Color.Silver;
            this.bunifuDatePicker1.BorderRadius = 1;
            this.bunifuDatePicker1.Color = System.Drawing.Color.Silver;
            this.bunifuDatePicker1.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.bunifuDatePicker1.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.bunifuDatePicker1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuDatePicker1.DisplayWeekNumbers = false;
            this.bunifuDatePicker1.DPHeight = 0;
            this.bunifuDatePicker1.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.bunifuDatePicker1.FillDatePicker = false;
            this.bunifuDatePicker1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuDatePicker1.ForeColor = System.Drawing.Color.Black;
            this.bunifuDatePicker1.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuDatePicker1.Icon")));
            this.bunifuDatePicker1.IconColor = System.Drawing.Color.Gray;
            this.bunifuDatePicker1.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.bunifuDatePicker1.LeftTextMargin = 5;
            validationObject16.CustomErrorMessage = "";
            validationObject16.Optional = false;
            validationObject16.Regex = null;
            validationObject16.TargetMember = "Text";
            validationObject16.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.bunifuDatePicker1, validationObject16);
            bindingObject16.BindingMember = "OrderDate";
            bindingObject16.BindingProperty = "Value";
            this.bindingProvider1.SetLink(this.bunifuDatePicker1, bindingObject16);
            this.bunifuDatePicker1.Location = new System.Drawing.Point(33, 202);
            this.bunifuDatePicker1.MinimumSize = new System.Drawing.Size(4, 32);
            this.bunifuDatePicker1.Name = "bunifuDatePicker1";
            this.bunifuDatePicker1.Size = new System.Drawing.Size(287, 32);
            this.bunifuDatePicker1.TabIndex = 30;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject17.CustomErrorMessage = "";
            validationObject17.Optional = false;
            validationObject17.Regex = null;
            validationObject17.TargetMember = "Text";
            validationObject17.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label13, validationObject17);
            bindingObject17.BindingMember = "";
            bindingObject17.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label13, bindingObject17);
            this.label13.Location = new System.Drawing.Point(616, 89);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 19);
            this.label13.TabIndex = 29;
            this.label13.Text = "Shipper";
            // 
            // lstSHipper
            // 
            this.lstSHipper.BackColor = System.Drawing.Color.Transparent;
            this.lstSHipper.BackgroundColor = System.Drawing.Color.White;
            this.lstSHipper.BorderColor = System.Drawing.Color.Silver;
            this.lstSHipper.BorderRadius = 1;
            this.lstSHipper.Color = System.Drawing.Color.Silver;
            this.lstSHipper.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.lstSHipper.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lstSHipper.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.lstSHipper.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lstSHipper.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.lstSHipper.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.lstSHipper.DisplayMember = "CompanyName";
            this.lstSHipper.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.lstSHipper.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.lstSHipper.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstSHipper.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.lstSHipper.FillDropDown = true;
            this.lstSHipper.FillIndicator = false;
            this.lstSHipper.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lstSHipper.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lstSHipper.ForeColor = System.Drawing.Color.Black;
            this.lstSHipper.FormattingEnabled = true;
            this.lstSHipper.Icon = null;
            this.lstSHipper.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.lstSHipper.IndicatorColor = System.Drawing.Color.DarkGray;
            this.lstSHipper.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.lstSHipper.IndicatorThickness = 2;
            this.lstSHipper.IsDropdownOpened = false;
            this.lstSHipper.ItemBackColor = System.Drawing.Color.White;
            this.lstSHipper.ItemBorderColor = System.Drawing.Color.White;
            this.lstSHipper.ItemForeColor = System.Drawing.Color.Black;
            this.lstSHipper.ItemHeight = 26;
            this.lstSHipper.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.lstSHipper.ItemHighLightForeColor = System.Drawing.Color.White;
            this.lstSHipper.ItemTopMargin = 3;
            bindingObject18.BindingMember = "ShipperId";
            bindingObject18.BindingProperty = "SelectedValue";
            this.bindingProvider1.SetLink(this.lstSHipper, bindingObject18);
            validationObject18.CustomErrorMessage = "";
            validationObject18.Optional = false;
            validationObject18.Regex = "(.|\\s)*\\S(.|\\s)*";
            validationObject18.TargetMember = "SelectedValue";
            validationObject18.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.NotEmpty;
            this.validationProvider1.SetLink(this.lstSHipper, validationObject18);
            this.lstSHipper.Location = new System.Drawing.Point(620, 111);
            this.lstSHipper.Name = "lstSHipper";
            this.lstSHipper.Size = new System.Drawing.Size(288, 32);
            this.lstSHipper.TabIndex = 28;
            this.lstSHipper.Text = null;
            this.lstSHipper.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.lstSHipper.TextLeftMargin = 5;
            this.lstSHipper.ValueMember = "Id";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject19.CustomErrorMessage = "";
            validationObject19.Optional = false;
            validationObject19.Regex = null;
            validationObject19.TargetMember = "Text";
            validationObject19.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label12, validationObject19);
            bindingObject19.BindingMember = "";
            bindingObject19.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label12, bindingObject19);
            this.label12.Location = new System.Drawing.Point(326, 89);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 19);
            this.label12.TabIndex = 27;
            this.label12.Text = "Employee";
            // 
            // lstEmployess
            // 
            this.lstEmployess.BackColor = System.Drawing.Color.Transparent;
            this.lstEmployess.BackgroundColor = System.Drawing.Color.White;
            this.lstEmployess.BorderColor = System.Drawing.Color.Silver;
            this.lstEmployess.BorderRadius = 1;
            this.lstEmployess.Color = System.Drawing.Color.Silver;
            this.lstEmployess.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.lstEmployess.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lstEmployess.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.lstEmployess.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lstEmployess.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.lstEmployess.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.lstEmployess.DisplayMember = "Name";
            this.lstEmployess.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.lstEmployess.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.lstEmployess.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstEmployess.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.lstEmployess.FillDropDown = true;
            this.lstEmployess.FillIndicator = false;
            this.lstEmployess.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lstEmployess.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lstEmployess.ForeColor = System.Drawing.Color.Black;
            this.lstEmployess.FormattingEnabled = true;
            this.lstEmployess.Icon = null;
            this.lstEmployess.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.lstEmployess.IndicatorColor = System.Drawing.Color.DarkGray;
            this.lstEmployess.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.lstEmployess.IndicatorThickness = 2;
            this.lstEmployess.IsDropdownOpened = false;
            this.lstEmployess.ItemBackColor = System.Drawing.Color.White;
            this.lstEmployess.ItemBorderColor = System.Drawing.Color.White;
            this.lstEmployess.ItemForeColor = System.Drawing.Color.Black;
            this.lstEmployess.ItemHeight = 26;
            this.lstEmployess.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.lstEmployess.ItemHighLightForeColor = System.Drawing.Color.White;
            this.lstEmployess.ItemTopMargin = 3;
            bindingObject20.BindingMember = "EmployeeID";
            bindingObject20.BindingProperty = "SelectedValue";
            this.bindingProvider1.SetLink(this.lstEmployess, bindingObject20);
            validationObject20.CustomErrorMessage = "";
            validationObject20.Optional = false;
            validationObject20.Regex = "(.|\\s)*\\S(.|\\s)*";
            validationObject20.TargetMember = "SelectedValue";
            validationObject20.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.NotEmpty;
            this.validationProvider1.SetLink(this.lstEmployess, validationObject20);
            this.lstEmployess.Location = new System.Drawing.Point(326, 111);
            this.lstEmployess.Name = "lstEmployess";
            this.lstEmployess.Size = new System.Drawing.Size(288, 32);
            this.lstEmployess.TabIndex = 26;
            this.lstEmployess.Text = null;
            this.lstEmployess.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.lstEmployess.TextLeftMargin = 5;
            this.lstEmployess.ValueMember = "Id";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject21.CustomErrorMessage = "";
            validationObject21.Optional = false;
            validationObject21.Regex = null;
            validationObject21.TargetMember = "Text";
            validationObject21.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label11, validationObject21);
            bindingObject21.BindingMember = "";
            bindingObject21.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label11, bindingObject21);
            this.label11.Location = new System.Drawing.Point(29, 89);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 19);
            this.label11.TabIndex = 25;
            this.label11.Text = "Customer";
            // 
            // lstCutomer
            // 
            this.lstCutomer.BackColor = System.Drawing.Color.Transparent;
            this.lstCutomer.BackgroundColor = System.Drawing.Color.White;
            this.lstCutomer.BorderColor = System.Drawing.Color.Silver;
            this.lstCutomer.BorderRadius = 1;
            this.lstCutomer.Color = System.Drawing.Color.Silver;
            this.lstCutomer.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.lstCutomer.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lstCutomer.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.lstCutomer.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.lstCutomer.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.lstCutomer.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.lstCutomer.DisplayMember = "CompanyName";
            this.lstCutomer.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.lstCutomer.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.lstCutomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstCutomer.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.lstCutomer.FillDropDown = true;
            this.lstCutomer.FillIndicator = false;
            this.lstCutomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lstCutomer.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lstCutomer.ForeColor = System.Drawing.Color.Black;
            this.lstCutomer.FormattingEnabled = true;
            this.lstCutomer.Icon = null;
            this.lstCutomer.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.lstCutomer.IndicatorColor = System.Drawing.Color.DarkGray;
            this.lstCutomer.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.lstCutomer.IndicatorThickness = 2;
            this.lstCutomer.IsDropdownOpened = false;
            this.lstCutomer.ItemBackColor = System.Drawing.Color.White;
            this.lstCutomer.ItemBorderColor = System.Drawing.Color.White;
            this.lstCutomer.ItemForeColor = System.Drawing.Color.Black;
            this.lstCutomer.ItemHeight = 26;
            this.lstCutomer.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.lstCutomer.ItemHighLightForeColor = System.Drawing.Color.White;
            this.lstCutomer.ItemTopMargin = 3;
            bindingObject22.BindingMember = "CustomerID";
            bindingObject22.BindingProperty = "SelectedValue";
            this.bindingProvider1.SetLink(this.lstCutomer, bindingObject22);
            validationObject22.CustomErrorMessage = "";
            validationObject22.Optional = false;
            validationObject22.Regex = "(.|\\s)*\\S(.|\\s)*";
            validationObject22.TargetMember = "SelectedValue";
            validationObject22.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.NotEmpty;
            this.validationProvider1.SetLink(this.lstCutomer, validationObject22);
            this.lstCutomer.Location = new System.Drawing.Point(32, 111);
            this.lstCutomer.Name = "lstCutomer";
            this.lstCutomer.Size = new System.Drawing.Size(288, 32);
            this.lstCutomer.TabIndex = 24;
            this.lstCutomer.Text = null;
            this.lstCutomer.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.lstCutomer.TextLeftMargin = 5;
            this.lstCutomer.ValueMember = "Id";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Crimson;
            this.btnClose.FlatAppearance.BorderSize = 2;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.Crimson;
            validationObject23.CustomErrorMessage = "";
            validationObject23.Optional = false;
            validationObject23.Regex = null;
            validationObject23.TargetMember = "Text";
            validationObject23.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.btnClose, validationObject23);
            bindingObject23.BindingMember = "";
            bindingObject23.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.btnClose, bindingObject23);
            this.btnClose.Location = new System.Drawing.Point(736, 586);
            this.btnClose.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(89, 38);
            this.btnClose.TabIndex = 23;
            this.btnClose.Text = "CLOSE";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btnSave.FlatAppearance.BorderSize = 2;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            validationObject24.CustomErrorMessage = "";
            validationObject24.Optional = false;
            validationObject24.Regex = null;
            validationObject24.TargetMember = "Text";
            validationObject24.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.btnSave, validationObject24);
            bindingObject24.BindingMember = "";
            bindingObject24.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.btnSave, bindingObject24);
            this.btnSave.Location = new System.Drawing.Point(831, 586);
            this.btnSave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(89, 38);
            this.btnSave.TabIndex = 22;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.ForeColor = System.Drawing.Color.Black;
            validationObject25.CustomErrorMessage = "";
            validationObject25.Optional = false;
            validationObject25.Regex = "(.|\\s)*\\S(.|\\s)*";
            validationObject25.TargetMember = "Text";
            validationObject25.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.NotEmpty;
            this.validationProvider1.SetLink(this.textBox3, validationObject25);
            bindingObject25.BindingMember = "ShipAddress";
            bindingObject25.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.textBox3, bindingObject25);
            this.textBox3.Location = new System.Drawing.Point(620, 297);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(288, 27);
            this.textBox3.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject26.CustomErrorMessage = "";
            validationObject26.Optional = false;
            validationObject26.Regex = null;
            validationObject26.TargetMember = "Text";
            validationObject26.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label3, validationObject26);
            bindingObject26.BindingMember = "";
            bindingObject26.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label3, bindingObject26);
            this.label3.Location = new System.Drawing.Point(616, 273);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "Ship Address";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.ForeColor = System.Drawing.Color.Black;
            validationObject27.CustomErrorMessage = "";
            validationObject27.Optional = false;
            validationObject27.Regex = "(.|\\s)*\\S(.|\\s)*";
            validationObject27.TargetMember = "Text";
            validationObject27.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.NotEmpty;
            this.validationProvider1.SetLink(this.textBox2, validationObject27);
            bindingObject27.BindingMember = "ShipName";
            bindingObject27.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.textBox2, bindingObject27);
            this.textBox2.Location = new System.Drawing.Point(326, 297);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(288, 27);
            this.textBox2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject28.CustomErrorMessage = "";
            validationObject28.Optional = false;
            validationObject28.Regex = null;
            validationObject28.TargetMember = "Text";
            validationObject28.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label2, validationObject28);
            bindingObject28.BindingMember = "";
            bindingObject28.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label2, bindingObject28);
            this.label2.Location = new System.Drawing.Point(322, 273);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Ship Name";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            validationObject29.CustomErrorMessage = "";
            validationObject29.Optional = false;
            validationObject29.Regex = "^[0-9]*(\\.[0-9]{1,4})?$";
            validationObject29.TargetMember = "Text";
            validationObject29.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.Decimal;
            this.validationProvider1.SetLink(this.textBox1, validationObject29);
            bindingObject29.BindingMember = "Freight";
            bindingObject29.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.textBox1, bindingObject29);
            this.textBox1.Location = new System.Drawing.Point(32, 297);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(288, 27);
            this.textBox1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject30.CustomErrorMessage = "";
            validationObject30.Optional = false;
            validationObject30.Regex = null;
            validationObject30.TargetMember = "Text";
            validationObject30.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label1, validationObject30);
            bindingObject30.BindingMember = "";
            bindingObject30.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label1, bindingObject30);
            this.label1.Location = new System.Drawing.Point(27, 273);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Freight";
            // 
            // validationProvider1
            // 
            this.validationProvider1.ErrorColor = System.Drawing.Color.Crimson;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            validationObject1.CustomErrorMessage = "";
            validationObject1.Optional = false;
            validationObject1.Regex = null;
            validationObject1.TargetMember = "Text";
            validationObject1.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.label14, validationObject1);
            bindingObject1.BindingMember = "";
            bindingObject1.BindingProperty = "Text";
            this.bindingProvider1.SetLink(this.label14, bindingObject1);
            this.label14.Location = new System.Drawing.Point(355, 482);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 19);
            this.label14.TabIndex = 47;
            this.label14.Text = "Deleted";
            // 
            // bunifuCheckBox2
            // 
            this.bunifuCheckBox2.AllowBindingControlAnimation = true;
            this.bunifuCheckBox2.AllowBindingControlColorChanges = false;
            this.bunifuCheckBox2.AllowBindingControlLocation = true;
            this.bunifuCheckBox2.AllowCheckBoxAnimation = false;
            this.bunifuCheckBox2.AllowCheckmarkAnimation = true;
            this.bunifuCheckBox2.AllowOnHoverStates = true;
            this.bunifuCheckBox2.AutoCheck = true;
            this.bunifuCheckBox2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCheckBox2.BackgroundImage")));
            this.bunifuCheckBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bunifuCheckBox2.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.bunifuCheckBox2.BorderRadius = 12;
            this.bunifuCheckBox2.Checked = true;
            this.bunifuCheckBox2.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.bunifuCheckBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuCheckBox2.CustomCheckmarkImage = null;
            validationObject2.CustomErrorMessage = "";
            validationObject2.Optional = false;
            validationObject2.Regex = null;
            validationObject2.TargetMember = "Text";
            validationObject2.ValidationType = Kimtoo.ValidationProvider.ValidationTypes.None;
            this.validationProvider1.SetLink(this.bunifuCheckBox2, validationObject2);
            bindingObject2.BindingMember = "Deleted";
            bindingObject2.BindingProperty = "Checked";
            this.bindingProvider1.SetLink(this.bunifuCheckBox2, bindingObject2);
            this.bunifuCheckBox2.Location = new System.Drawing.Point(327, 482);
            this.bunifuCheckBox2.MinimumSize = new System.Drawing.Size(17, 17);
            this.bunifuCheckBox2.Name = "bunifuCheckBox2";
            this.bunifuCheckBox2.OnCheck.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuCheckBox2.OnCheck.BorderRadius = 12;
            this.bunifuCheckBox2.OnCheck.BorderThickness = 2;
            this.bunifuCheckBox2.OnCheck.CheckBoxColor = System.Drawing.Color.DodgerBlue;
            this.bunifuCheckBox2.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox2.OnCheck.CheckmarkThickness = 2;
            this.bunifuCheckBox2.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.bunifuCheckBox2.OnDisable.BorderRadius = 12;
            this.bunifuCheckBox2.OnDisable.BorderThickness = 2;
            this.bunifuCheckBox2.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.bunifuCheckBox2.OnDisable.CheckmarkThickness = 2;
            this.bunifuCheckBox2.OnHoverChecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuCheckBox2.OnHoverChecked.BorderRadius = 12;
            this.bunifuCheckBox2.OnHoverChecked.BorderThickness = 2;
            this.bunifuCheckBox2.OnHoverChecked.CheckBoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuCheckBox2.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox2.OnHoverChecked.CheckmarkThickness = 2;
            this.bunifuCheckBox2.OnHoverUnchecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuCheckBox2.OnHoverUnchecked.BorderRadius = 12;
            this.bunifuCheckBox2.OnHoverUnchecked.BorderThickness = 1;
            this.bunifuCheckBox2.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.bunifuCheckBox2.OnUncheck.BorderRadius = 12;
            this.bunifuCheckBox2.OnUncheck.BorderThickness = 1;
            this.bunifuCheckBox2.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.Size = new System.Drawing.Size(21, 21);
            this.bunifuCheckBox2.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.bunifuCheckBox2.TabIndex = 46;
            this.bunifuCheckBox2.ThreeState = false;
            this.bunifuCheckBox2.ToolTipText = null;
            // 
            // FrmOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(950, 653);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.bunifuCheckBox2);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.bunifuDatePicker3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bunifuDatePicker2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bunifuDatePicker1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lstSHipper);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lstEmployess);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lstCutomer);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Load += new System.EventHandler(this.FrmOrder_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuFormDock docker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private Kimtoo.ValidationProvider.ValidationProvider validationProvider1;
        private Kimtoo.BindingProvider.BindingProvider bindingProvider1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;
        private Bunifu.UI.WinForms.BunifuSnackbar bunifuSnackbar1;
        private System.Windows.Forms.Label label12;
        private Bunifu.UI.WinForms.BunifuDropdown lstEmployess;
        private System.Windows.Forms.Label label11;
        private Bunifu.UI.WinForms.BunifuDropdown lstCutomer;
        private System.Windows.Forms.Label label13;
        private Bunifu.UI.WinForms.BunifuDropdown lstSHipper;
        private System.Windows.Forms.Label label6;
        private Bunifu.UI.WinForms.BunifuDatePicker bunifuDatePicker3;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuDatePicker bunifuDatePicker2;
        private System.Windows.Forms.Label label4;
        private Bunifu.UI.WinForms.BunifuDatePicker bunifuDatePicker1;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private Bunifu.UI.WinForms.BunifuCheckBox bunifuCheckBox2;
    }
}