﻿using DGV.Framework;
using NothwindSystem.Data;
using NothwindSystem.Data.Models;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NothwindSystem.Gui.Forms.Dialogs
{
    public partial class FrmItems : Form
    {
        private Order order;
        public FrmItems(Order order)
        {
            InitializeComponent();
            this.order = order;
            grid.Bind(order.GetOrderItems());
            txtTotal.Text = "TOTAL: " + (order.GetTotal().ToString("C2"));
            txtDiscount.Text = "DISCOUNT: " + (order.GetDiscount().ToString("C2"));
            grid.OnDelete<OrderItem>((orderItemm, row) => db.Get().Delete(orderItemm)>0);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            new FrmOrderItem(order, null).ShowDialog() ;
             grid.Bind(order.GetOrderItems());
            txtTotal.Text = "TOTAL: " + (order.GetTotal().ToString("C2"));
            txtDiscount.Text = "DISCOUNT: " + (order.GetDiscount().ToString("C2"));
        }

        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex<2)
            {
                new FrmOrderItem(order, grid.GetCurrentRecord<OrderItem>()).ShowDialog();
                grid.Bind(order.GetOrderItems());
                txtTotal.Text = "TOTAL: " + (order.GetTotal().ToString("C2"));
                txtDiscount.Text = "DISCOUNT: " + (order.GetDiscount().ToString("C2"));
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            grid.DeleteRow<OrderItem>();
             grid.Bind(order.GetOrderItems());
            txtTotal.Text = "TOTAL: " + (order.GetTotal().ToString("C2"));
            txtDiscount.Text = "DISCOUNT: " + (order.GetDiscount().ToString("C2"));
        }

        private void bunifuAppBar1_IconClick(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
