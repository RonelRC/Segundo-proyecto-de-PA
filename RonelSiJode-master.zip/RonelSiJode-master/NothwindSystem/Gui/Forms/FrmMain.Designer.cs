﻿namespace NothwindSystem.Gui.Forms
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation1 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.docker = new Bunifu.UI.WinForms.BunifuFormDock();
            this.bunifuAppBar1 = new Bunifu.Utils.BunifuAppBar();
            this.menu = new NavigationMenu.NavigtionMenu();
            this.pages = new Bunifu.UI.WinForms.BunifuPages();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pageCustomers1 = new NothwindSystem.Gui.Pages.PageCustomers();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pageOrders1 = new NothwindSystem.Gui.Pages.PageOrders();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.pageEmployees1 = new NothwindSystem.Gui.Pages.PageEmployees();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.pageSuppliers1 = new NothwindSystem.Gui.Pages.PageSuppliers();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.pageShippers1 = new NothwindSystem.Gui.Pages.PageShippers();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.pageProducts1 = new NothwindSystem.Gui.Pages.PageProducts();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.pageCategories1 = new NothwindSystem.Gui.Pages.PageCategories();
            this.pages.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.SuspendLayout();
            // 
            // docker
            // 
            this.docker.AllowFormDragging = true;
            this.docker.AllowFormDropShadow = true;
            this.docker.AllowFormResizing = true;
            this.docker.AllowHidingBottomRegion = true;
            this.docker.AllowOpacityChangesWhileDragging = false;
            this.docker.BorderOptions.BottomBorder.BorderColor = System.Drawing.Color.Silver;
            this.docker.BorderOptions.BottomBorder.BorderThickness = 1;
            this.docker.BorderOptions.BottomBorder.ShowBorder = true;
            this.docker.BorderOptions.LeftBorder.BorderColor = System.Drawing.Color.Silver;
            this.docker.BorderOptions.LeftBorder.BorderThickness = 1;
            this.docker.BorderOptions.LeftBorder.ShowBorder = true;
            this.docker.BorderOptions.RightBorder.BorderColor = System.Drawing.Color.Silver;
            this.docker.BorderOptions.RightBorder.BorderThickness = 1;
            this.docker.BorderOptions.RightBorder.ShowBorder = true;
            this.docker.BorderOptions.TopBorder.BorderColor = System.Drawing.Color.Silver;
            this.docker.BorderOptions.TopBorder.BorderThickness = 1;
            this.docker.BorderOptions.TopBorder.ShowBorder = true;
            this.docker.ContainerControl = this;
            this.docker.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.docker.DockingIndicatorsOpacity = 0.5D;
            this.docker.DockingOptions.DockAll = true;
            this.docker.DockingOptions.DockBottomLeft = true;
            this.docker.DockingOptions.DockBottomRight = true;
            this.docker.DockingOptions.DockFullScreen = true;
            this.docker.DockingOptions.DockLeft = true;
            this.docker.DockingOptions.DockRight = true;
            this.docker.DockingOptions.DockTopLeft = true;
            this.docker.DockingOptions.DockTopRight = true;
            this.docker.FormDraggingOpacity = 0.9D;
            this.docker.ParentForm = this;
            this.docker.ShowCursorChanges = true;
            this.docker.ShowDockingIndicators = true;
            this.docker.TitleBarOptions.AllowFormDragging = true;
            this.docker.TitleBarOptions.BunifuFormDock = this.docker;
            this.docker.TitleBarOptions.DoubleClickToExpandWindow = true;
            this.docker.TitleBarOptions.TitleBarControl = null;
            this.docker.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            // 
            // bunifuAppBar1
            // 
            this.bunifuAppBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuAppBar1.BackColor = System.Drawing.Color.RoyalBlue;
            this.bunifuAppBar1.ControlBoxColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuAppBar1.ControlBoxColorActive = System.Drawing.Color.White;
            this.bunifuAppBar1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.bunifuAppBar1.ForeColor = System.Drawing.Color.White;
            this.bunifuAppBar1.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuAppBar1.Icon")));
            this.bunifuAppBar1.Location = new System.Drawing.Point(12, 12);
            this.bunifuAppBar1.Name = "bunifuAppBar1";
            this.bunifuAppBar1.Size = new System.Drawing.Size(1135, 46);
            this.bunifuAppBar1.TabIndex = 0;
            this.bunifuAppBar1.Title = "Northwind System";
            this.bunifuAppBar1.TitleMargin = new System.Windows.Forms.Padding(47, 12, 0, 0);
            // 
            // menu
            // 
            this.menu.AutoScroll = true;
            this.menu.BackColor = System.Drawing.Color.WhiteSmoke;
            this.menu.BackColor_Click = System.Drawing.Color.Gainsboro;
            this.menu.BackColor_Hover = System.Drawing.Color.Gainsboro;
            this.menu.BackColor_Selected = System.Drawing.Color.RoyalBlue;
            this.menu.DisableToggling = new string[0];
            this.menu.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.menu.ForeColor_Selected = System.Drawing.Color.White;
            this.menu.IsExpandable = false;
            this.menu.IsExpanded = true;
            this.menu.ItemHeight = 50;
            this.menu.ItemImageSize = new System.Drawing.Size(20, 20);
            this.menu.ItemPadding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.menu.ItemRightImageMargin = 20;
            this.menu.ItemRightImageSize = new System.Drawing.Size(15, 15);
            this.menu.Items = new NavigationMenu.ButtonItem[] {
        ((NavigationMenu.ButtonItem)(resources.GetObject("menu.Items"))),
        ((NavigationMenu.ButtonItem)(resources.GetObject("menu.Items1"))),
        ((NavigationMenu.ButtonItem)(resources.GetObject("menu.Items2")))};
            this.menu.ItemTextMargin = 8;
            this.menu.Location = new System.Drawing.Point(12, 66);
            this.menu.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(199, 585);
            this.menu.TabIndex = 1;
            this.menu.OnItemSelected += new NavigationMenu.NavigtionMenu.OnSelectEventHandler(this.menu_OnItemSelected);
            // 
            // pages
            // 
            this.pages.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.pages.AllowTransitions = false;
            this.pages.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pages.Controls.Add(this.tabPage2);
            this.pages.Controls.Add(this.tabPage3);
            this.pages.Controls.Add(this.tabPage4);
            this.pages.Controls.Add(this.tabPage5);
            this.pages.Controls.Add(this.tabPage6);
            this.pages.Controls.Add(this.tabPage7);
            this.pages.Controls.Add(this.tabPage8);
            this.pages.Location = new System.Drawing.Point(217, 66);
            this.pages.Multiline = true;
            this.pages.Name = "pages";
            this.pages.Page = this.tabPage2;
            this.pages.PageIndex = 0;
            this.pages.PageName = "tabPage2";
            this.pages.PageTitle = "Sales.Customers";
            this.pages.SelectedIndex = 0;
            this.pages.Size = new System.Drawing.Size(930, 587);
            this.pages.TabIndex = 2;
            animation1.AnimateOnlyDifferences = false;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.pages.Transition = animation1;
            this.pages.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.Custom;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage2.Controls.Add(this.pageCustomers1);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(922, 561);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sales.Customers";
            // 
            // pageCustomers1
            // 
            this.pageCustomers1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pageCustomers1.Location = new System.Drawing.Point(3, 3);
            this.pageCustomers1.Name = "pageCustomers1";
            this.pageCustomers1.Size = new System.Drawing.Size(916, 555);
            this.pageCustomers1.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage3.Controls.Add(this.pageOrders1);
            this.tabPage3.Location = new System.Drawing.Point(4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(922, 561);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Sales.Orders";
            // 
            // pageOrders1
            // 
            this.pageOrders1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pageOrders1.Location = new System.Drawing.Point(3, 3);
            this.pageOrders1.Name = "pageOrders1";
            this.pageOrders1.Size = new System.Drawing.Size(916, 555);
            this.pageOrders1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage4.Controls.Add(this.pageEmployees1);
            this.tabPage4.Location = new System.Drawing.Point(4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(922, 561);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Operations.Employees";
            // 
            // pageEmployees1
            // 
            this.pageEmployees1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pageEmployees1.Location = new System.Drawing.Point(3, 3);
            this.pageEmployees1.Name = "pageEmployees1";
            this.pageEmployees1.Size = new System.Drawing.Size(916, 555);
            this.pageEmployees1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage5.Controls.Add(this.pageSuppliers1);
            this.tabPage5.Location = new System.Drawing.Point(4, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(922, 561);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Operations.Suppliers";
            // 
            // pageSuppliers1
            // 
            this.pageSuppliers1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pageSuppliers1.Location = new System.Drawing.Point(3, 3);
            this.pageSuppliers1.Name = "pageSuppliers1";
            this.pageSuppliers1.Size = new System.Drawing.Size(916, 555);
            this.pageSuppliers1.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage6.Controls.Add(this.pageShippers1);
            this.tabPage6.Location = new System.Drawing.Point(4, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(922, 561);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Operations.Shippers";
            // 
            // pageShippers1
            // 
            this.pageShippers1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pageShippers1.Location = new System.Drawing.Point(3, 3);
            this.pageShippers1.Name = "pageShippers1";
            this.pageShippers1.Size = new System.Drawing.Size(916, 555);
            this.pageShippers1.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage7.Controls.Add(this.pageProducts1);
            this.tabPage7.Location = new System.Drawing.Point(4, 4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(922, 561);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Catalog.Products";
            // 
            // pageProducts1
            // 
            this.pageProducts1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pageProducts1.Location = new System.Drawing.Point(3, 3);
            this.pageProducts1.Name = "pageProducts1";
            this.pageProducts1.Size = new System.Drawing.Size(916, 555);
            this.pageProducts1.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage8.Controls.Add(this.pageCategories1);
            this.tabPage8.Location = new System.Drawing.Point(4, 4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(922, 561);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Catalog.Categories";
            // 
            // pageCategories1
            // 
            this.pageCategories1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pageCategories1.Location = new System.Drawing.Point(3, 3);
            this.pageCategories1.Name = "pageCategories1";
            this.pageCategories1.Size = new System.Drawing.Size(916, 555);
            this.pageCategories1.TabIndex = 0;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1159, 665);
            this.Controls.Add(this.pages);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.bunifuAppBar1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmMain";
            this.pages.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuFormDock docker;
        private Bunifu.Utils.BunifuAppBar bunifuAppBar1;
        private NavigationMenu.NavigtionMenu menu;
        private Bunifu.UI.WinForms.BunifuPages pages;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private Pages.PageCustomers pageCustomers1;
        private Pages.PageOrders pageOrders1;
        private Pages.PageEmployees pageEmployees1;
        private Pages.PageSuppliers pageSuppliers1;
        private Pages.PageShippers pageShippers1;
        private Pages.PageCategories pageCategories1;
        private Pages.PageProducts pageProducts1;
    }
}