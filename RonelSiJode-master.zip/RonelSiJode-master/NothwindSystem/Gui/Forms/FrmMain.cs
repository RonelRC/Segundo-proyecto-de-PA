﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms; 

namespace NothwindSystem.Gui.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent(); 
        }

        private void menu_OnItemSelected(object sender, string path, EventArgs e)
        {
            pages.SetPage(path);
        }
    }
}
