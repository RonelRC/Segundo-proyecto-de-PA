﻿using ServiceStack.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NothwindSystem.Data.Models
{
    [Alias("shippers")]
    public class Shipper
    {
        [PrimaryKey,AutoIncrement]
        public int Id { get; set; }
        public string CompanyName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public bool Deleted { get; set; }
    }
}
