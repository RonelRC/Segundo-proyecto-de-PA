﻿using ServiceStack.DataAnnotations;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NothwindSystem.Data.Models
{
    [Alias("orders")]
    public class Order
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        [ForeignKey(typeof(Customer))]
        public int CustomerID { get; set; }

        [ForeignKey(typeof(Employee))]
        public int EmployeeID { get; set; }
        [ForeignKey(typeof(Shipper))]
        public int ShipperId { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now;
        public DateTime RequiredDate { get; set; } = DateTime.Now;
        public DateTime ShippedDate { get; set; } = DateTime.Now;
        public double Freight { get; set; }
        public string ShipName { get; set; } = string.Empty;
        public string ShipAddress { get; set; } = string.Empty;
        public string ShipCity { get; set; } = string.Empty;
        public string ShipRegion { get; set; } = string.Empty;
        public string ShipPostalCode { get; set; } = string.Empty;
        public string ShipCountry { get; set; } = string.Empty;

        public bool Deleted { get; set; }


        public IEnumerable<OrderItem> GetOrderItems() => db.Get().Select<OrderItem>(r => r.OrderID == Id);

        public double GetTotal() => GetOrderItems().Sum(r => r.GetTotal());
        public double GetPrice() => GetOrderItems().Sum(r => r.Quantity * r.UnitPrice);
        public double GetDiscount() => GetOrderItems().Sum(r => r.Discount);
        public Customer GetCustomer() => db.Get().SingleById<Customer>(CustomerID);
        public Employee GetEmployee() => db.Get().SingleById<Employee>(EmployeeID);
        public Shipper GetShipper() => db.Get().SingleById<Shipper>(ShipperId);
    }
}
