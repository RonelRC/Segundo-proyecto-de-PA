﻿using ServiceStack.DataAnnotations;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NothwindSystem.Data.Models
{
    [Alias("order_items")]
    public class OrderItem
    {
        [PrimaryKey,AutoIncrement]
        public int Id { get; set; }
        [ForeignKey(typeof(Order))]
        public int OrderID { get; set; }

        [ForeignKey(typeof(Product))] 
        public int ProductID { get; set; }
        public double UnitPrice { get; set; }
        public int Quantity { get; set; }
        public double Discount { get; set; }
        public bool Deleted { get; set; }

        public double GetTotal() =>  (UnitPrice * Quantity) - Discount;
        public Product GetProduct() => db.Get().SingleById<Product>(ProductID);
        public string GetProductName() => GetProduct().ProductName;



    }
}
