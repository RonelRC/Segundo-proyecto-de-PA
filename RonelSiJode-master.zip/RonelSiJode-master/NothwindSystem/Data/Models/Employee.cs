﻿using ServiceStack.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NothwindSystem.Data.Models
{
    [Alias("employees")]
    public class Employee
    {
        [PrimaryKey,AutoIncrement]
        public int Id { get; set; }
         
        public string Name { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string TitleOfCourtesy { get; set; } = string.Empty;
        public DateTime BirthDate { get; set; } = DateTime.Now;
        public DateTime HireDate { get; set; } = DateTime.Now;
        public string Address { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string Region { get; set; } = string.Empty;
        public string PostalCode { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
        public string HomePhone { get; set; } = string.Empty;
        public string Extension { get; set; } = string.Empty; 
        public string Notes { get; set; } = string.Empty;
        public string PhotoPath { get; set; } = string.Empty;
        public bool Deleted { get; set; }
    }
}
