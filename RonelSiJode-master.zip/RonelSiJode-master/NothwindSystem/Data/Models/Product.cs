﻿using ServiceStack.DataAnnotations;
using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NothwindSystem.Data.Models
{

    [Alias("products")]
    public class Product
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        [ForeignKey(typeof(Supplier))]
        public int SupplierID { get; set; }

        [ForeignKey(typeof(Category))]
        public int CategoryID { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string QuantityPerUnit { get; set; } = string.Empty;
        public double UnitPrice { get; set; }
        public double UnitsInStock { get; set; }
        public double UnitsOnOrder { get; set; }
        public double ReorderLevel { get; set; }
        public bool Discontinued { get; set; }
        public bool Deleted { get; set; }

        public Supplier GetSupplier() => db.Get().SingleById<Supplier>(SupplierID);
        public Category GetCategory() => db.Get().SingleById<Category>(CategoryID);
    }
}
