﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NothwindSystem.Data.Models;
using ServiceStack.OrmLite;

namespace NothwindSystem.Data
{
    public class db
    {
        private static IDbConnection _db; 
        public static Exception Exception;

        public static IDbConnection Get()
        {
            var dbFactory = new OrmLiteConnectionFactory
            (
                @"Data Source=DESKTOP-V01FUDJ;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False",
                SqlServerDialect.Provider);

            try
            {
                if (_db == null)
                {
                    _db = dbFactory.Open();
                    Migrate();
                }

                if (_db.State == ConnectionState.Broken || _db.State == ConnectionState.Closed)
                    _db = dbFactory.Open();

                return _db;
            }
            catch (Exception err)
            {
                Exception = err;
                return null;
            }
        }
 

        private static void Migrate()
        {
            var db = Get();
            db.CreateTableIfNotExists<Customer>();
            db.CreateTableIfNotExists<Shipper>();
            db.CreateTableIfNotExists<Supplier>();
            db.CreateTableIfNotExists<Category>();
            db.CreateTableIfNotExists<Product>(); 
            db.CreateTableIfNotExists<Employee>();
            db.CreateTableIfNotExists<Order>();
            db.CreateTableIfNotExists<OrderItem>();
        }
    }
}